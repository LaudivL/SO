#include "main.h"

int IO_init()
{
	UART_init();
	VGA_Screen_Init(); // Init VGA-Screen
}

void IO_write_info()
{
	char info[] = "Opdracht software ontwikkeling.\nDoor Laudi van Leiden enFloris Zorge.\nType 'help' voor hulp.\n";
	IO_writeMessage(&info[0]);
}

void IO_write_help()
{
	char H_lijn[] = "lijn(x,y,x',y',dikte,kleur);\n";
	char H_ellips[] = "ellips(x-mp,y-mp,radius-x,radius-y,kleur);\n";
	char H_rechthoek[] = "rechthoek(x-lo,y-lo,x-rb,y-rb,kleur);\n";
	char H_driehoek[] = "driehoek(x,y,x',y',x'',y'',kleur);\n";
	char H_tekst[] = 	"tekst(x,y,tekst,fontnaam,kleur,stijl);\n";
	char H_bitmap[] = "bitmap(nr,x-lo,y-lo);\n";
	char H_clearscherm[] = "clearscherm(kleur);\n";
	char H_wacht[] = "wacht(msecs);\n";
	char H_kleuren[] = "Kleuren: zwart, blauw, lichtblauw, groen, lichtgroen, cyaan, lichtcyaan, rood, lichtrood, magenta, lichtmagenta, bruin, geel, grijs, wit\n";
	char H_stijlen[] = "Stijlen: norm, vet, cursief\n";
	char H_bitmaps[] = "Bitmaps:\nnr 1: pijl links.\nnr 2: pijl rechts.\nnr 3: pijl boven.\nnr 4: pijl beneden.\nnr 5: smiley boos.\nnr 6: smiley blij.\n";
	IO_writeS("Function list:\n");
	IO_writeS(&H_lijn[0]);IO_writeS("\n");
	IO_writeS(&H_ellips[0]);IO_writeS("\n");
	IO_writeS(&H_rechthoek[0]);IO_writeS("\n");
	IO_writeS(&H_driehoek[0]);IO_writeS("\n");
	IO_writeS(&H_tekst[0]);IO_writeS("\n");
	IO_writeS(&H_bitmap[0]);IO_writeS("\n");
	IO_writeS(&H_clearscherm[0]);IO_writeS("\n");
	IO_writeS(&H_wacht[0]);IO_writeS("\n");
	IO_writeS("\n");
	IO_writeS(&H_kleuren[0]);IO_writeS("\n");
	IO_writeS(&H_stijlen[0]);IO_writeS("\n");
	IO_writeS(&H_bitmaps[0]);IO_writeS("\n");
}

void IO_read_rs232(char *pbuf)
{
	UART_gets(pbuf,0);
}

void IO_writeInt(const int integer)
{
	UART_putint(integer);
}

void IO_writeS(char *s)
{
	UART_puts(s);
}

void IO_writeChar(char s)
{
	UART_putchar(s);
}

void IO_writeMessage(const char* message)
{
	UART_puts(message);
}

void IO_log(int TYPE, const char* message)
{

	if(TYPE == _ERROR)
	{
		UART_puts("Error! ");UART_puts(message);UART_puts("\n");
	}
	if(TYPE == _WARNING)
	{
		UART_puts("Warning: ");UART_puts(message);UART_puts("\n");
	}
	if(TYPE == _NOTE)
	{
		UART_puts("NOTE: ");UART_puts(message);UART_puts("\n");
	}
}
