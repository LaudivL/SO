#ifndef IO_H
#define IO_H

#define _ERROR   	111
#define _WARNING 	110
#define _NOTE		101

int IO_init();
void IO_write_info();
void IO_write_help();
void IO_read_rs232(char *pbuf);
void IO_writeInt(const int integer);
void IO_writeS(char *s);
void IO_writeChar(char s);
void IO_writeMessage(const char* message);
void IO_log(int TYPE, const char* message);

#endif // IO_H
