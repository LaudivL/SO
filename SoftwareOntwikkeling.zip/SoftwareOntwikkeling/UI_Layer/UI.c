#include "main.h"
#include "string.h"
#include "Colors.h"

int UI(function_Details *pUI_FD)
{
	int error = 0;
	char buf[BUFFER_SIZE];
	int i;
	for(i = 0; i<BUFFER_SIZE; i++)
	{
		buf[i] = 0xff;
	}

	while(buf[1] == 0xff)
	{
		IO_read_rs232(&buf[0]);
	}

	if(buf[0]!= 0xff)
	{
		error = UI_check_buf(&buf[0], pUI_FD);
	}
	return error;
}

int UI_check_buf(char *pbuf, function_Details *pUI_FDcheck)
{
	char input[BUFFER_SIZE];
	char buf_check[BUFFER_SIZE];
	int IO_inputSize = 0;
	char parameterLocation[10];
	int counter;
	int BCerror = 0;

	//place the buf array into the buf_check array
	for(counter = 0; counter<BUFFER_SIZE; counter++)
	{
		buf_check[counter] = *pbuf;
		input[counter] = *pbuf;
		pbuf++;
	}

	#ifdef DEBUG
	IO_writeMessage("Input: ");IO_writeS(&buf_check[0]);IO_writeMessage("\n");
	#endif


	#ifdef DEBUG
	static int check_space = 1;
	#endif

	//remove spaces and determine input size
	counter = 0;
	for(counter = 0; counter <BUFFER_SIZE; counter++)
	{
		if(buf_check[counter] == '\0')
		{
			IO_inputSize = counter;
			counter = BUFFER_SIZE;
		}

		else if(buf_check[counter] == ' ')
		{
			#ifdef DEBUG
			if(check_space == 1)
			{
				check_space = 0;
				IO_log(_NOTE, "Removed spaces.");
			}
			#endif

			int s;
			for(s = counter; s<BUFFER_SIZE; s++)
			{
				buf_check[s] = buf_check[s+1];
			}
			counter--;
		}
	}

	//check number of parameters and locations
	pUI_FDcheck->NumberOfParameters = 0;
	counter = 0;
	for(counter = 0; counter <=IO_inputSize; counter++)
	{
		if(buf_check[counter] == '\0')
		{
			parameterLocation[pUI_FDcheck->NumberOfParameters] = counter;//end of parameters
			pUI_FDcheck->NumberOfParameters ++;
			counter = 255;

		}
		else if(buf_check[counter] == ',')
		{
			parameterLocation[pUI_FDcheck->NumberOfParameters] = counter;
			pUI_FDcheck->NumberOfParameters ++;
		}
	}

	#ifdef SOFTWAREDEBUG
	IO_writeMessage("Nr of parameters: ");IO_writeInt(pUI_FDcheck->NumberOfParameters);IO_writeMessage("\n");
	#endif

	//determine witch function is called
	pUI_FDcheck->FNumber = UNKNOWN;
	switch (parameterLocation[0])
	{
		case 4:
				if(buf_check[0] == 'l'&&\
				   buf_check[1] == 'i'&&\
				   buf_check[2] == 'j'&&\
				   buf_check[3] == 'n')
				{pUI_FDcheck->FNumber = Lijn;}
		   else if((buf_check[0] == 'H' || buf_check[0] == 'h')&&\
				   (buf_check[1] == 'E' || buf_check[1] == 'e')&&\
				   (buf_check[2] == 'L' || buf_check[2] == 'l')&&\
				   (buf_check[3] == 'P' || buf_check[3] == 'p'))
				{pUI_FDcheck->FNumber = HELP;}
		   	    else{pUI_FDcheck->FNumber = UNKNOWN;}
		   	   break;
		case 5:
				if(buf_check[0] == 't'&&\
				   buf_check[1] == 'e'&&\
				   buf_check[2] == 'k'&&\
				   buf_check[3] == 's'&&\
				   buf_check[4] == 't')
				{pUI_FDcheck->FNumber = Tekst;}
		   else if(buf_check[0] == 'w'&&\
				   buf_check[1] == 'a'&&\
				   buf_check[2] == 'c'&&\
				   buf_check[3] == 'h'&&\
				   buf_check[4] == 't')
				{pUI_FDcheck->FNumber = Wacht;}
				else {pUI_FDcheck->FNumber = UNKNOWN;}
				break;
		case 6:
				if(buf_check[0] == 'e'&&\
				   buf_check[1] == 'l'&&\
				   buf_check[2] == 'l'&&\
				   buf_check[3] == 'i'&&\
				   buf_check[4] == 'p'&&\
				   buf_check[5] == 's')
				{pUI_FDcheck->FNumber = Ellips;}
		   else if(buf_check[0] == 'b'&&\
				   buf_check[1] == 'i'&&\
				   buf_check[2] == 't'&&\
				   buf_check[3] == 'm'&&\
				   buf_check[4] == 'a'&&\
				   buf_check[5] == 'p')
				{pUI_FDcheck->FNumber = Bitmap;}
				else {pUI_FDcheck->FNumber = UNKNOWN;}
				break;
		case 8:
				if(buf_check[0] == 'd'&&\
				   buf_check[1] == 'r'&&\
				   buf_check[2] == 'i'&&\
				   buf_check[3] == 'e'&&\
				   buf_check[4] == 'h'&&\
				   buf_check[5] == 'o'&&\
				   buf_check[6] == 'e'&&\
				   buf_check[7] == 'k')
				{pUI_FDcheck->FNumber = Driehoek;}
				else {pUI_FDcheck->FNumber = UNKNOWN;}
				break;
		case 9:
				if(buf_check[0] == 'r'&&\
				   buf_check[1] == 'e'&&\
				   buf_check[2] == 'c'&&\
				   buf_check[3] == 'h'&&\
				   buf_check[4] == 't'&&\
				   buf_check[5] == 'h'&&\
				   buf_check[6] == 'o'&&\
				   buf_check[7] == 'e'&&\
				   buf_check[8] == 'k')
				{pUI_FDcheck->FNumber = Rechthoek;}
				else {pUI_FDcheck->FNumber = UNKNOWN;}
				break;
		case 11:
				if(buf_check[0] == 'c'&&\
				   buf_check[1] == 'l'&&\
				   buf_check[2] == 'e'&&\
				   buf_check[3] == 'a'&&\
				   buf_check[4] == 'r'&&\
				   buf_check[5] == 's'&&\
				   buf_check[6] == 'c'&&\
				   buf_check[7] == 'h'&&\
				   buf_check[8] == 'e'&&\
				   buf_check[9] == 'r'&&\
				   buf_check[10] == 'm')
				{pUI_FDcheck->FNumber = Clearscherm;}
				else {pUI_FDcheck->FNumber = UNKNOWN;}
				break;
		default: pUI_FDcheck->FNumber = UNKNOWN;
	};
	#ifdef SOFTWAREDEBUG
	IO_writeMessage("FunctionNr: ");IO_writeInt(pUI_FDcheck->FNumber);IO_writeMessage("\n");
	#endif

	if(pUI_FDcheck->FNumber == UNKNOWN)
	{
		#ifdef DEBUG
		IO_log(_ERROR,"Unknow function.");
		#endif
		return _ERROR;
	}
	else
	{
		//Create a string array with all the parameters
		char parameter[pUI_FDcheck->NumberOfParameters][30];
		int Pnr,c;//Parameter Number, counter

		for(Pnr = 0; Pnr<((pUI_FDcheck->NumberOfParameters)-1);Pnr++)
		{
			for(c = 0; c<((parameterLocation[Pnr+1]-parameterLocation[Pnr])-1);c++)
			{
				parameter[Pnr][c] = buf_check[parameterLocation[Pnr]+c+1];
			}
			parameter[Pnr][c] = '\0'; //end parameter string
			#ifdef SOFTWAREDEBUG
			IO_writeMessage(&parameter[Pnr][0]);
			IO_writeMessage("\n");
			#endif
		}

		//check if the number of parameters is correct and if the paramater valeus are correct.
		switch(pUI_FDcheck->FNumber)
		{
			case Lijn: //lijn, x, y, x�, y�, dikte, kleur
				if((pUI_FDcheck->NumberOfParameters-1) != 6)
				{
					#ifdef DEBUG
					IO_log(_ERROR,"Invalid number of parameters!");
					#endif
					BCerror = 1;
				}
				else
				{
					if(parameter[0][0] == '0' && parameter[0][1] == '\0'){pUI_FDcheck->x1 = 0;}
					else
					{
						pUI_FDcheck->x1 = atoi(&parameter[0][0]);
						if(pUI_FDcheck->x1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: x1!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[1][0] == '0' && parameter[1][1] == '\0'){pUI_FDcheck->y1 = 0;}
					else
					{
						pUI_FDcheck->y1 = atoi(&parameter[1][0]);
						if(pUI_FDcheck->y1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: y1!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[2][0] == '0' && parameter[2][1] == '\0'){pUI_FDcheck->x2 = 0;}
					else
					{
						pUI_FDcheck->x2 = atoi(&parameter[2][0]);
						if(pUI_FDcheck->x2 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: x2!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[3][0] == '0' && parameter[3][1] == '\0'){pUI_FDcheck->y2 = 0;}
					else
					{
						pUI_FDcheck->y2 = atoi(&parameter[3][0]);
						if(pUI_FDcheck->y2 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: y2!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[4][0] == '0' && parameter[4][1] == '\0')
					{
						#ifdef DEBUG
						IO_log(_ERROR,"Dikte can't be equal to 0.");
						#endif
					}
					else
					{
						pUI_FDcheck->dikte = atoi(&parameter[4][0]);
						if(pUI_FDcheck->dikte <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: dikte!");
							#endif
							BCerror = 1;
						}
					}

					pUI_FDcheck->kleur = UI_check_color(&parameter[5][0]);
					if(pUI_FDcheck->kleur == UNKNOWNCOLOR)
					{
						#ifdef DEBUG
						IO_log(_ERROR,"Unknown color!");
						#endif
						BCerror = 1;
					}
				}
				break;
//------------------------------------------------------------------------------------------
			case Ellips: //ellips, x-mp, y-mp, radius-x, radius-y, kleur
				if((pUI_FDcheck->NumberOfParameters-1) != 5)
				{
					#ifdef DEBUG
					IO_log(_ERROR,"Invalid number of parameters!");
					#endif
					BCerror = 1;
				}
				else
				{
					if(parameter[0][0] == '0' && parameter[0][1] == '\0'){pUI_FDcheck->x1 = 0;}
					else
					{
						pUI_FDcheck->x1 = atoi(&parameter[0][0]);
						if(pUI_FDcheck->x1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: x1!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[1][0] == '0' && parameter[1][1] == '\0'){pUI_FDcheck->y1 = 0;}
					else
					{
						pUI_FDcheck->y1 = atoi(&parameter[1][0]);
						if(pUI_FDcheck->y1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: y1!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[2][0] == '0' && parameter[2][1] == '\0')
					{
						#ifdef DEBUG
						IO_log(_ERROR,"Radius-x can't be equal to 0.");
						#endif
					}
					else
					{
						pUI_FDcheck->radiusX = atoi(&parameter[2][0]);
						if(pUI_FDcheck->radiusX <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: radiusX!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[3][0] == '0' && parameter[3][1] == '\0')
					{
						#ifdef DEBUG
						IO_log(_ERROR,"Radius-y can't be equal to 0.");
						#endif
					}
					else
					{
						pUI_FDcheck->radiusY = atoi(&parameter[3][0]);
						if(pUI_FDcheck->radiusY <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: radiusY!");
							#endif
							BCerror = 1;
						}
					}
					pUI_FDcheck->kleur = UI_check_color(&parameter[4][0]);
					if(pUI_FDcheck->kleur == UNKNOWNCOLOR)
					{
						#ifdef DEBUG
						IO_log(_ERROR,"Unknown color!");
						#endif
						BCerror = 1;
					}
				}
				break;
//------------------------------------------------------------------------------------------
			case Rechthoek: //rechthoek, x-lo, y-lo, x-rb, y-rb, kleur
				if((pUI_FDcheck->NumberOfParameters-1) != 5)
				{
					#ifdef DEBUG
					IO_log(_ERROR,"Invalid number of parameters!");
					#endif
					BCerror = 1;
				}
				else
				{
					if(parameter[0][0] == '0' && parameter[0][1] == '\0'){pUI_FDcheck->x1 = 0;}
					else
					{
						pUI_FDcheck->x1 = atoi(&parameter[0][0]);
						if(pUI_FDcheck->x1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: x1!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[1][0] == '0' && parameter[1][1] == '\0'){pUI_FDcheck->y1 = 0;}
					else
					{
						pUI_FDcheck->y1 = atoi(&parameter[1][0]);
						if(pUI_FDcheck->y1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: y1!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[2][0] == '0' && parameter[2][1] == '\0'){pUI_FDcheck->x2 = 0;}
					else
					{
						pUI_FDcheck->x2 = atoi(&parameter[2][0]);
						if(pUI_FDcheck->x2 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: x2!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[3][0] == '0' && parameter[3][1] == '\0'){pUI_FDcheck->y2 = 0;}
					else
					{
						pUI_FDcheck->y2 = atoi(&parameter[3][0]);
						if(pUI_FDcheck->y2 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: y2!");
							#endif
							BCerror = 1;
						}
					}
					pUI_FDcheck->kleur = UI_check_color(&parameter[4][0]);
					if(pUI_FDcheck->kleur == UNKNOWNCOLOR)
					{
						#ifdef DEBUG
						IO_log(_ERROR,"Unknown color!");
						#endif
						BCerror = 1;
					}
				}
				break;
//------------------------------------------------------------------------------------------
			case Driehoek: //driehoek, x, y, x�, y�,x�, y�, kleur
				if((pUI_FDcheck->NumberOfParameters-1) != 7)
				{
					#ifdef DEBUG
					IO_log(_ERROR,"Invalid number of parameters!");
					#endif
					BCerror = 1;
				}
				else
				{
					if(parameter[0][0] == '0' && parameter[0][1] == '\0'){pUI_FDcheck->x1 = 0;}
					else
					{
						pUI_FDcheck->x1 = atoi(&parameter[0][0]);
						if(pUI_FDcheck->x1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: x1!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[1][0] == '0' && parameter[1][1] == '\0'){pUI_FDcheck->y1 = 0;}
					else
					{
						pUI_FDcheck->y1 = atoi(&parameter[1][0]);
						if(pUI_FDcheck->y1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: y1!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[2][0] == '0' && parameter[2][1] == '\0'){pUI_FDcheck->x2 = 0;}
					else
					{
						pUI_FDcheck->x2 = atoi(&parameter[2][0]);
						if(pUI_FDcheck->x2 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: x2!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[3][0] == '0' && parameter[3][1] == '\0'){pUI_FDcheck->y2 = 0;}
					else
					{
						pUI_FDcheck->y2 = atoi(&parameter[3][0]);
						if(pUI_FDcheck->y2 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: y2!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[4][0] == '0' && parameter[4][1] == '\0'){pUI_FDcheck->x3 = 0;}
					else
					{
						pUI_FDcheck->x3 = atoi(&parameter[4][0]);
						if(pUI_FDcheck->x3 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: x3!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[5][0] == '0' && parameter[5][1] == '\0'){pUI_FDcheck->y3 = 0;}
					else
					{
						pUI_FDcheck->y3 = atoi(&parameter[5][0]);
						if(pUI_FDcheck->y3 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: y3!");
							#endif
							BCerror = 1;
						}
					}
					pUI_FDcheck->kleur = UI_check_color(&parameter[6][0]);
					if(pUI_FDcheck->kleur == UNKNOWNCOLOR)
					{
						#ifdef DEBUG
						IO_log(_ERROR,"Unknown color!");
						#endif
						BCerror = 1;
					}
				}
				break;
//------------------------------------------------------------------------------------------
			case Tekst: //tekst, x, y, tekst, (fontnaam), kleur, stijl: �norm�,�vet�,�cursief�
				if((pUI_FDcheck->NumberOfParameters-1) != 5)
				{
					#ifdef DEBUG
					IO_log(_ERROR,"Invalid number of parameters!");
					#endif
					BCerror = 1;
				}
				else
				{
					if(parameter[0][0] == '0' && parameter[0][1] == '\0'){pUI_FDcheck->x1 = 0;}
					else
					{
						pUI_FDcheck->x1 = atoi(&parameter[0][0]);
						if(pUI_FDcheck->x1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: x1!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[1][0] == '0' && parameter[1][1] == '\0'){pUI_FDcheck->y1 = 0;}
					else
					{
						pUI_FDcheck->y1 = atoi(&parameter[1][0]);
						if(pUI_FDcheck->y1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: y1!");
							#endif
							BCerror = 1;
						}
					}

					char recTekst[BUFFER_SIZE];
					UI_recover_tekst(&recTekst[0], &input[0]);
					#ifdef SOFTWAREDEBUG
						IO_writeMessage(&recTekst[0]);IO_writeMessage("\n");
					#endif
					strcpy(&pUI_FDcheck->tekst[0], &recTekst[0]);

					pUI_FDcheck->kleur = UI_check_color(&parameter[3][0]);
					if(pUI_FDcheck->kleur == UNKNOWNCOLOR)
					{
						#ifdef DEBUG
						IO_log(_ERROR,"Unknown color!");
						#endif
						BCerror = 1;
					}

						 if(strcmp(&parameter[4][0], "norm") == 0)		{pUI_FDcheck->stijl = 0;}
					else if(strcmp(&parameter[4][0], "vet") == 0)		{pUI_FDcheck->stijl = 1;}
					else if(strcmp(&parameter[4][0], "cursief") == 0)	{pUI_FDcheck->stijl = 2;}
					else
					{
						#ifdef DEBUG
						IO_log(_ERROR,"Unknown style!");
						#endif
						BCerror = 1;
					}
				}
				break;
//----------------------------------------------------------------------------------------------------
			case Bitmap: //bitmap, nr, x-lo, y-lo  [tenminste: pijl (in 4 richtingen), smiley (boos, blij)]
				if((pUI_FDcheck->NumberOfParameters-1) != 3)
				{
					#ifdef DEBUG
					IO_log(_ERROR,"Invalid number of parameters!");
					#endif
					BCerror = 1;
				}
				else
				{
					if(parameter[0][0] == '0' && parameter[0][1] == '\0'){pUI_FDcheck->bitmapNr = 0;}
					else
					{
						pUI_FDcheck->bitmapNr = atoi(&parameter[0][0]);
						if(pUI_FDcheck->bitmapNr <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: bitmapNr!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[1][0] == '0' && parameter[1][1] == '\0'){pUI_FDcheck->x1 = 0;}
					else
					{
						pUI_FDcheck->x1 = atoi(&parameter[1][0]);
						if(pUI_FDcheck->x1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: x1!");
							#endif
							BCerror = 1;
						}
					}
					if(parameter[2][0] == '0' && parameter[2][1] == '\0'){pUI_FDcheck->y1 = 0;}
					else
					{
						pUI_FDcheck->y1 = atoi(&parameter[2][0]);
						if(pUI_FDcheck->y1 <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: y1!");
							#endif
							BCerror = 1;
						}
					}
				}
				break;
//------------------------------------------------------------------------------------------
			case Clearscherm: //clearscherm, kleur
				if((pUI_FDcheck->NumberOfParameters-1) != 1)
				{
					#ifdef DEBUG
					IO_log(_ERROR,"Invalid number of parameters!");
					#endif
					BCerror = 1;
				}
				else
				{
					pUI_FDcheck->kleur = UI_check_color(&parameter[0][0]);
					if(pUI_FDcheck->kleur == UNKNOWNCOLOR)
					{
						#ifdef DEBUG
						IO_log(_ERROR,"Unknown color!");
						#endif
						BCerror = 1;
					}
				}
				break;
//------------------------------------------------------------------------------------------
			case Wacht: //wacht, msecs
				if((pUI_FDcheck->NumberOfParameters-1) != 1)
				{
					#ifdef DEBUG
					IO_log(_ERROR,"Invalid number of parameters!");
					#endif
					BCerror = 1;
				}
				else
				{
					if(parameter[0][0] == '0' && parameter[0][1] == '\0'){pUI_FDcheck->msec = 0;}
					else
					{
						pUI_FDcheck->msec = atoi(&parameter[0][0]);
						if(pUI_FDcheck->msec <= 0)
						{
							#ifdef DEBUG
							IO_log(_ERROR,"invalid value for: msec!");
							#endif
							BCerror = 1;
						}
					}
				}
				break;
		};
	}
	if(BCerror != 0){ return _ERROR;}
	else{ return 0;}
}

int UI_check_color(char *color)
{
		 if(strcmp(color, "zwart") == 0)		{return VGA_COL_BLACK;}
	else if(strcmp(color, "blauw") == 0)		{return VGA_COL_BLUE;}
	else if(strcmp(color, "lichtblauw") == 0)	{return VGA_COL_LIGHTBLUE;}
	else if(strcmp(color, "groen") == 0)		{return VGA_COL_GREEN;}
	else if(strcmp(color, "lichtgroen") == 0)	{return VGA_COL_LIGHTGREEN;}
	else if(strcmp(color, "cyaan") == 0)		{return VGA_COL_CYAN;}
	else if(strcmp(color, "lichtcyaan") == 0)	{return VGA_COL_LIGHTCYAN;}
	else if(strcmp(color, "rood") == 0)			{return VGA_COL_RED;}
	else if(strcmp(color, "lichtrood") == 0)	{return VGA_COL_LIGHTRED;}
	else if(strcmp(color, "magenta") == 0)		{return VGA_COL_MAGENTA;}
	else if(strcmp(color, "lichtmagenta") == 0)	{return VGA_COL_LIGHTMAGENTA;}
	else if(strcmp(color, "bruin") == 0)		{return VGA_COL_BROWN;}
	else if(strcmp(color, "geel") == 0)			{return VGA_COL_YELLOW;}
	else if(strcmp(color, "grijs") == 0)		{return VGA_COL_GRAY;}
	else if(strcmp(color, "wit") == 0)			{return VGA_COL_WHITE;}
	else return 0;
}

void UI_recover_tekst(char *pdest, char *pinput)
{
	//tekst is placed after the thired ','
	int counter = 0;
	int i,j;
	for(i = 0; i< BUFFER_SIZE; i++)
	{
		if(*pinput == ',')
		{
			counter++;
		}
		if(counter == TEKSTSTARTPAR)
		{
			pinput++;
			for(j = i; j<BUFFER_SIZE; j++) //fill tekst string until next ','
			{
				if(*pinput != ',')
				{
					*pdest = *pinput;
					pinput++;
					pdest++;
				}
				else //end tekst string and close loops
				{
					*pdest = '\0';
					j = BUFFER_SIZE;
					i = BUFFER_SIZE;
				}
			}
		}
		pinput++;
	}
}
