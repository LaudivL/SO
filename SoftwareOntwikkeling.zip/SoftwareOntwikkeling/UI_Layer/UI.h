#ifndef UI_H
#define UI_H

#include "main.h"


#define TEKSTSTARTPAR 3
#define UNKNOWNCOLOR 0xAA

int UI(function_Details *pUI_FD);
int UI_check_buf(char *pbuf, function_Details *pUI_FDcheck);
int UI_check_color(char *color);
void UI_recover_tekst(char *pdest, char *pinput);

#endif // UI_H
