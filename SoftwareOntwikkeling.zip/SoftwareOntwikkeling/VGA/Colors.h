#ifndef Colors_H
#define Colors_H

//--------------------------------------------------------------
// color designation
// 8bit color (R3G3B2)
// Red   (3bit) -> Bit7-Bit5
// Green (3bit) -> Bit4-Bit2
// Blue  (2bit) -> Bit1-Bit0
//--------------------------------------------------------------
#define  VGA_COL_BLACK          0x00
#define  VGA_COL_WHITE          0xFF
#define  VGA_COL_GRAY 			0xBF
#define  VGA_COL_BLUE           0x03
#define  VGA_COL_LIGHTBLUE      0x73
#define  VGA_COL_GREEN          0x1C
#define  VGA_COL_LIGHTGREEN     0x5C
#define  VGA_COL_RED            0xE0
#define  VGA_COL_LIGHTRED       0xE9
#define  VGA_COL_YELLOW         0xFC
#define  VGA_COL_BROWN			0X88
#define  VGA_COL_CYAN           0x1F
#define  VGA_COL_LIGHTCYAN      0x7F
#define  VGA_COL_MAGENTA        0xE3
#define  VGA_COL_LIGHTMAGENTA   0xE2

#endif //Colors.h
