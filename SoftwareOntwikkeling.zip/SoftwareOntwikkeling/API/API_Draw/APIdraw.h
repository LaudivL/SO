#ifndef APIdraw_H
#define APIdraw_H

void APIdraw_Line(int _x1, int _y1, int _x2, int _y2, int _d, int color);
void APIdraw_Ellips(int _x1, int _y1, int _radiusX, int _radiusY, int color);
void APIdraw_Squere(int _x1, int _y1, int _x2, int _y2, int color);
void APIdraw_Triangle(int _x1, int _y1, int _x2, int _y2, int _x3, int _y3, int color);
void APIdraw_Tekst(int _x1, int _y1, const char* _Tekst, int color, int _stijl);
void APIdraw_Bitmap(int _bitmapNr, int _x1, int _y1);
void APIdraw_Clearscreen(int color);
void APIdraw_delay(int _msec);

int API_checkCoordinates(int _x1, int _y1, int _d);

#endif //APIdraw_H
