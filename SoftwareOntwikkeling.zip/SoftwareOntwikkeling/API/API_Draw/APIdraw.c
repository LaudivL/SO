#include "APIdraw.h"
#include "delay.h"
#include "APIio.h"
#include "main.h"
#include "bitmap.h"
#include "Colors.h"
#include "ASCIIbitmap.h"

void APIdraw_Line(int _x1, int _y1, int _x2, int _y2, int _d, int color)
{
 int error = 0;
 error  = error + API_checkCoordinates(_x1,_y1,_d);
 error  = error + API_checkCoordinates(_x2,_y2,_d);

 if(error == 0)
 {
   if(_x1>_x2)
   {
     int tempX, tempY;
     tempX = _x1;
     tempY = _y1;
     _x1 = _x2;
     _y1 = _y2;
     _x2 = tempX;
     _y2 = tempY;
   }

   int Xdif = _x2 - _x1;
   int Ydif = _y2 - _y1;
   _d = (int)_d/2;
   if(_d<=0){_d=1;}
   int x,y,dx,dy;
   float fy;

   if(Xdif != 0 && Ydif != 0)
   {
     for(x = 0; x<Xdif; x++)
     {
       fy = (x*Ydif)/Xdif;
       y = (int)fy;
       for(dy = (-_d +1); dy<=(_d-1); dy++)
       {
         for(dx = (-_d +1); dx<(_d-1);dx++)
         {
        	 APIio_SetPixel((x+dx)+_x1,(y+dy)+_y1,color);
         }
       }
     }
   }
   else
   {
	 if(Xdif == 0 && Ydif==0)
	 {
		 for(dy = (-_d +1); dy<=(_d-1); dy++)
		 {
			 for(dx = (-_d +1); dx<(_d-1);dx++)
			 {
				 APIio_SetPixel(dx+_x1,dy+_y1,color);
			 }
		 }
	 }
	 else if(Xdif == 0)
     {
       int i;
       for(i = 0; i<Ydif; i++)
       {
         for(dx = (-_d +1); dx<=(_d-1);dx++)
         {
         	APIio_SetPixel((_x1+dx),_y1+i,color);
         }
       }
     }
	 else if(Ydif == 0)
     {
       int i;
       for(i = 0; i<Xdif; i++)
       {
         for(dy = (-_d +1); dy<=(_d-1); dy++)
         {
        	 APIio_SetPixel((_x1+i),(_y1+dy),color);
         }
       }
     }
   }
 }
}

void APIdraw_Ellips(int _x1, int _y1, int _radiusX, int _radiusY, int color)
{
	int error = 0;
	error  = error + API_checkCoordinates(_x1,_y1,(_radiusX*2));
	error  = error + API_checkCoordinates(_x1,_y1,(_radiusY*2));

	if(error == 0)
	{
		int x_cor;
		float y_cor;
		float X_kwadraat = 0;
		float A_kwadraat= 0;

		A_kwadraat = (int)pow(_radiusX,2);

		for (x_cor=0; x_cor<=_radiusX; x_cor++)
		{
		  X_kwadraat = (int)pow(x_cor,2);

		  y_cor = ((float)_radiusY/_radiusX)*(sqrt(A_kwadraat-X_kwadraat));

		  APIio_SetPixel(x_cor+_x1,(int)y_cor+_y1,color);
		  APIio_SetPixel(_x1-x_cor,(int)y_cor+_y1,color);
		  APIio_SetPixel(x_cor+_x1,_y1-(int)y_cor,color);
		  APIio_SetPixel(_x1-x_cor,_y1-(int)y_cor,color);
		}
	}
}

void APIdraw_Squere(int _x1, int _y1, int _x2, int _y2, int color)
{
	int error = 0;
	error  = error + API_checkCoordinates(_x1,_y1,1);
	error  = error + API_checkCoordinates(_x2,_y2,1);

	if(error == 0)
	{
		int _x3,_x4,_y3,_y4;
		int d = 1;

		_x3 = _x1;
		_y3 = _y2;
		_x4 = _x2;
		_y4 = _y1;

		APIdraw_Line(_x1,_y1,_x3,_y3,d,color);
		APIdraw_Line(_x3,_y3,_x2,_y2,d,color);
		APIdraw_Line(_x4,_y4,_x2,_y2,d,color);
		APIdraw_Line(_x1,_y1,_x4,_y4,d,color);
	}
}

void APIdraw_Triangle(int _x1, int _y1, int _x2, int _y2, int _x3, int _y3, int color)
{

	int error = 0;
	error  = error + API_checkCoordinates(_x1,_y1,1);
	error  = error + API_checkCoordinates(_x2,_y2,1);
	error  = error + API_checkCoordinates(_x3,_y3,1);

	if(error == 0)
	{
		int d = 4;

		APIdraw_Line(_x3,_y3,_x1,_y1,d,color);
		APIdraw_Line(_x2,_y2,_x3,_y3,d,color);
		APIdraw_Line(_x2,_y2,_x1,_y1,d,color);
	}
}

void APIdraw_Tekst(int _x1, int _y1, const char* _Tekst, int color, int _stijl)
{
	int error = 0;
	error  = error + API_checkCoordinates(_x1,_y1,1);

	if(error == 0)
	{

	}
}

void APIdraw_Bitmap(int _bitmapNr, int _x1, int _y1)
{
	int error = 0;
	error  = error + API_checkCoordinates(_x1,_y1,1);

	if(_bitmapNr<0 || _bitmapNr > (BITMAP_AMOUNT-1))
	{
		#ifdef DEBUG
		IO_log(_ERROR,"Unknown bitmap number!");
		#endif
		error = 1;
	}

	if(error == 0)
	{
		int r;
		int c;
		int startX = _x1-(bitmap_SizeX/2);
		int startY = _y1-(bitmap_SizeY/2);

		for(r=0;r<bitmap_SizeY;r++)
		{
		  for(c=0;c<bitmap_SizeX;c++)
		  {
		    if(bitmap[_bitmapNr][r][c] == 1)
		    {
		    	APIio_SetPixel(startX+c, startY+r, VGA_COL_YELLOW);
		    }
		  }
		}
	}
}

void APIdraw_Clearscreen(int color)
{
	APIio_FillScreen(color);
}

void APIdraw_delay(int _msec)
{
	DELAY_ms(_msec);
}

int API_checkCoordinates(int _x1, int _y1, int _d)
{
	if(_x1< 0 || _x1 > VGA_DISPLAY_X  || _y1 < 0 || _y1 > VGA_DISPLAY_Y)
	{
		#ifdef DEBUG
		IO_log(_ERROR,"Coordinate out of screen!");
		IO_writeMessage("Xmax: ");IO_writeInt(VGA_DISPLAY_X);IO_writeMessage("\tYmax: ");IO_writeInt(VGA_DISPLAY_Y );IO_writeMessage("\n");
		IO_writeMessage("Input: ");IO_writeInt(_x1);IO_writeMessage("\t");IO_writeInt(_y1);IO_writeMessage("\n");
		#endif
		return 1;
	}
	else
	{
		return 0;
	}
}
