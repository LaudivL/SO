#include "APIio.h"

void APIio_ScreenInit(void)
{
	VGA_Screen_Init();
}

void APIio_FillScreen(uint8_t c)
{
	VGA_FillScreen(c);
}

void APIio_SetPixel(uint16_t _xp, uint16_t _yp, uint8_t _color)
{
	if((_xp>=0 && _xp <= VGA_DISPLAY_X)&&(_yp>=0 && _yp <= VGA_DISPLAY_Y))
	{
		VGA_SetPixel(_xp, _yp, _color);
	}
}
