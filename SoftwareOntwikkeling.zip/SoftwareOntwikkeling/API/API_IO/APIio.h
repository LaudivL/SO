#ifndef APIio_H
#define APIio_H
#include "VGA.h"
#include "math.h"

void APIio_ScreenInit(void);
void APIio_FillScreen(uint8_t c);
void APIio_SetPixel(uint16_t _xp, uint16_t _yp, uint8_t _color);

#endif //APIio_H
