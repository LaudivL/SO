//--------------------------------------------------------------
// File     : main.c
// Datum    : 07.05.2018
// Version  : 1.0
// Autor    : UB
// mods by	: Floris Zorge, Laudi van Leiden.
// CPU      : STM32F4
// IDE      : CooCox CoIDE 1.7.x
// Module   : CMSIS_BOOT, M4_CMSIS_CORE
// Function : VGA_core DMA LIB 320x240, 8bit color
//--------------------------------------------------------------

#include "main.h"
#include "includes.h"
#include "delay.h"

void setup()
{
	SystemInit();	// System speed to 168MHz
	IO_init();
	IO_write_info();
	DELAY_init();
}

int main(void)
{
	function_Details function;
	char error = 0;

	setup();

	while(TRUE)
	{
		error = UI(&function);
		if(error == 0)
		{
			Logic(&function);
		}

	}
}
