#ifndef MAIN_H
#define MAIN_H

#define DEBUG
#define SOFTWAREDEBUG

#define BUFFER_SIZE 255

#define UNKNOWN		0
#define Lijn 		1
#define Ellips 		2
#define Rechthoek 	3
#define Driehoek 	4
#define Tekst 		5
#define Bitmap 		6
#define Clearscherm 7
#define Wacht 		8
#define HELP		9

struct function_D;

typedef struct function_D
{
	int FNumber;
	int NumberOfParameters;

	int x1,x2,x3,y1,y2,y3;
	int kleur;
	int dikte;
	int radiusX;
	int radiusY;
	int bitmapNr;
	int msec;
	int stijl;

	char tekst[BUFFER_SIZE];
	char fontnaam[BUFFER_SIZE];

}function_Details;

//--------------------------------------------------------------
// Includes
//--------------------------------------------------------------
#include "stm32f4xx.h"
#include "UI.h"
#include "Logic.h"
#include "IO.h"
//--------------------------------------------------------------


#endif // MAIN_H



