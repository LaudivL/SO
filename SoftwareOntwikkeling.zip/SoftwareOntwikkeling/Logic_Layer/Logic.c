#include "main.h"

int Logic(function_Details *LL_FD)
{
	switch(LL_FD->FNumber)
	{
		case Lijn:
			 APIdraw_Line(LL_FD->x1, LL_FD->y1, LL_FD->x2, LL_FD->y2, LL_FD->dikte, LL_FD->kleur);
			break;
		case Ellips:
			 APIdraw_Ellips(LL_FD->x1, LL_FD->y1, LL_FD->radiusX, LL_FD->radiusY, LL_FD->kleur);
			break;
		case Rechthoek:
			 APIdraw_Squere(LL_FD->x1, LL_FD->y1, LL_FD->x2, LL_FD->y2, LL_FD->kleur);
			break;
		case Driehoek:
			 APIdraw_Triangle(LL_FD->x1, LL_FD->y1, LL_FD->x2, LL_FD->y2, LL_FD->x3, LL_FD->y3, LL_FD->kleur);
			break;
		case Tekst:
			 APIdraw_Tekst(LL_FD->x1, LL_FD->y1, &LL_FD->tekst[0],LL_FD->kleur,LL_FD->stijl);
			break;
		case Bitmap:
			 APIdraw_Bitmap(LL_FD->bitmapNr, LL_FD->x1, LL_FD->y1);
			break;
		case Clearscherm:
			APIdraw_Clearscreen(LL_FD->kleur);
			break;
		case Wacht:
			APIdraw_delay(LL_FD->msec);
			break;
		case HELP:
			IO_write_help();
			break;
	};
}
