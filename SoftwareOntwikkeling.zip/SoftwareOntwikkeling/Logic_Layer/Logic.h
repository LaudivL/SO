#ifndef LOGIC_H
#define LOGIC_H

int Logic(function_Details *LL_FD);

#endif // UI_H
