#ifndef ASCIIbitmap_H
#define ASCIIbitmap_H


typedef struct fontstyle
{
	char font1 [][];

	char font2 [][];
} font;

#endif
